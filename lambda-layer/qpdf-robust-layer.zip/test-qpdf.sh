#!/bin/bash
echo "🧪 Probando qpdf en el layer..."
/opt/bin/qpdf --version
echo "✅ Layer funcionando correctamente"
