# qpdf Lambda Layer

Este layer proporciona qpdf para AWS Lambda.

## Uso

```javascript
const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);

// Usar qpdf
const { stdout } = await execAsync('/opt/bin/qpdf --version');
```

## Comandos comunes

- `qpdf --version` - Ver versión
- `qpdf --password=PASS --decrypt input.pdf output.pdf` - Desbloquear PDF
- `qpdf --check input.pdf` - Verificar PDF
